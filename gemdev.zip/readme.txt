LICENSE
The template is offered for free use under the open source MIT license for any type and any number of projects.


FILE STRUCTURE
- index.html holds the entire content
- css/styles.css custom css styling
- js/scripts.js custom js code
- images folder contains all the images
- the rest are files specific to different frameworks and dependencies


FRAMEWORKS & DEPENDENCIES
- Bootstrap https://getbootstrap.com/
- jQuery https://jquery.com/ 
- jQuery Easing https://jqueryui.com/easing/
- Magnific Popup https://dimsemenov.com/plugins/magnific-popup/
- Font Awesome for icons https://fontawesome.com/


IMAGES
All images are included in the download package and can be reused in your projects. The ones mentioned below come for outside resources. The ones not mentioned come from inside resources like created by Inovatik or purchased special license from authors. Either way you can use them for free in your project if you want.
- Details lightbox: https://www.pexels.com/photo/woman-in-white-t-shirt-holding-smartphone-in-front-of-laptop-914931/


CREDITS
Special thank you for:
- Wave code html, css, js by Ted: https://codepen.io/tedmcdo/pen/PqxKXg
